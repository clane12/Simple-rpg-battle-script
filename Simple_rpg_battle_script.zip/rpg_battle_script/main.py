from classes.chac_class import bcolors, chac
from classes.magic import spell

#dark destruction magic
fire = spell('fireball', 20, 100, 'dark')
blizzard = spell('ice-sting', 20, 100, 'dark')
thunder= spell('Thunderstorm', 20, 100, 'dark')
slingshot = spell('slingshot', 20, 100, 'dark')
quake = spell('quake', 20, 100, 'dark')
meteor = spell('meteor', 20, 100, 'dark')

#light retoration magic
cure = spell('heal', 20, 50, 'light')
cura = spell('heal1', 30, 100, 'light')


chacter = chac(500, 100, 50, [fire, thunder, blizzard, cure], 60)
enemy = chac(1000, 100, 30, [], 60)

running = True
i = 0

bc = bcolors
print(bc.FAIL + bc.BOLD + "The battle has begun" + bc.ENDC)

while running:
    print("=================================")
    chacter.choose_actions()
    choice = int(input("choose an option:"))
    choice1 = choice - 1
    print("you choose", choice1)

    if choice1 == 0:
        dmg = chacter.gen_damage()
        enemy.take_dmg(dmg)
        print("you attacked", dmg, "enemy health is", enemy.get_hp())

    elif choice1 == 1:
        chacter.choose_spells()
        choice2 = int(input("choose an option")) - 1
        print("you chose the spell", choice2)



        current_mp = chacter.get_mp()

        spell = chacter.magic[choice2]
        mg_dmg = spell.gen_spell_dmg()





        if spell.cost > current_mp:
            print("you don't have enough magic points")
            continue


        chacter.reduce_mp(spell.cost)

        if spell.type == 'light':
            chacter.heal(mg_dmg)
            print("player was healed", spell.name, "heal for", mg_dmg, "yout hp is", chacter.hp)
        elif spell.type == 'black':
            enemy.take_dmg(mg_dmg)
            print("you used", spell.name, "deals", str(mg_dmg), "enemy health is", enemy.get_hp())
            print("your current mp is", chacter.get_mp())


    if enemy.get_hp() == 0:
        print("enemy is dead")
        running = False

    enemy_choice = 1
    enemy_dmg = enemy.gen_damage()
    chacter.take_dmg(enemy_dmg)
    print("enemy attacked", enemy_dmg, "your health is", chacter.get_hp())

    if chacter.get_hp() == 0:
        print("you are dead")
        running = False

