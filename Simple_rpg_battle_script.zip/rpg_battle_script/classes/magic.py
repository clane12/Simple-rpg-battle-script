import random
class spell:
    def __init__(self, name, cost, dmg, type):
        self.name = name
        self.cost = cost
        self.dmg = dmg
        self.type = type

    def gen_spell_dmg(self):
        spdl = self.dmg - 15
        spdh = self.dmg + 15
        return random.randrange(spdl, spdh)